import AppBg from "../assets/images/beamerxuserflow BG.png";

const Home = () => {
  return (
    <>
      <div className="homeContainer">
        <h2></h2>
        <img style={{ width: "60%" }} src={AppBg}></img>
      </div>
    </>
  );
};

export default Home;
